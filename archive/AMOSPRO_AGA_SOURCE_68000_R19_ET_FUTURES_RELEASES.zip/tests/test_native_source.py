"""Gate A documentation: strict AP20 R19 + real ASM source verification.

Run: python -m unittest discover -s tests -p 'test_native_source.py' -v
No HUNK or archived .Lib is changed.
"""
from __future__ import annotations
from pathlib import Path
import json
import re
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import decoder68k as d
import generate_aga_native_source as x
import m68k_emit_reference as e

R19=ROOT/'reference'/'AMOSPro_AGA_R19.lib'
# The reference .Lib is provided by the user for local tests only, and is
# deliberately not shipped in this source package. On a checkout use dist/.
if not R19.is_file():R19=ROOT/'dist'/'AMOSPro_AGA.Lib'

REGEX_EA=re.compile(r'^(.+?)\(a([0-7])\)$')


def compile_r19_mouse(source,axis):
    """Assemble the ACTUAL .s statements through the builder's 68k emitter.

    Unlike checking disassembly comments, this proves that the explicitly
    written mnemonics/operands in AGA_MOUSE_R19_NATIVE.s encode to exactly
    the bytes contained in AP20 entry 28/29.
    """
    start='Aga_Mouse_'+axis.upper()+':'
    stop='Aga_Mouse_'+('Y' if axis=='x' else 'X')+':'
    lines=source.splitlines()
    begun=False; c=e.Code();ending=False;getp=False
    equ={}
    branches={'bra':0,'bne':6,'beq':7,'bmi':11,'bcc':4}
    for raw in lines:
        line=raw.split(';',1)[0].strip()
        if not line:continue
        m=re.match(r'^([A-Za-z_]\w*)\s+equ\s+(\$[0-9A-Fa-f]+|\d+)$',line,re.I)
        if m:equ[m[1].lower()]=int(m[2].replace('$','0x'),0);continue
        if line==start:begun=True;continue
        if not begun:continue
        if line==stop:break
        if line.endswith(':'):
            c.label((line[1:-1] if line.startswith('.') else line[:-1]).lower());continue
        if line=='dc.b "GetP"':getp=True;continue
        if ending:raise AssertionError('unexpected instruction after RTS: '+line)
        parts=line.split(None,1)
        op=parts[0].lower();a=parts[1].strip().lower() if len(parts)>1 else ''
        if op=='movem.l':
            if a.endswith(',-(sp)'):c.raw('48e7efee');continue
            if a.startswith('(sp)+,'):c.raw('4cdf77f7');continue
        if op=='rts':c.raw('4e75');ending=True;continue
        if op=='moveq' and a=='#0,d2':c.raw('7400');continue
        if op=='ext.l' and a in ('d1','d3'):
            c.raw('48c'+('1' if a=='d1' else '3'));continue
        if op in ('beq.w','bne.w','bmi.w','bcc.w','bra.w'):
            c.branch(branches[op.split('.')[0]],a.lstrip('.'));continue
        if op=='tst.l':
            assert a.startswith('d');c.tst(e.D(int(a[1])));continue
        if op in ('cmp.l','add.l'):
            a1,a2=a.split(',')
            assert a1.startswith('d') and a2.startswith('d')
            c.alu(op.split('.')[0],e.D(int(a1[1])),int(a2[1]));continue
        if op in ('movea.l','move.l','move.w'):
            # Source has no indexed EA / PCs in R19 M8 functions.
            left,right=a.split(',')
            def operand(p):
                if p.startswith('#'):return e.I(int(p[1:]),'l')
                if re.fullmatch(r'[da][0-7]',p):return (e.D if p[0]=='d' else e.A)(int(p[1]))
                m=REGEX_EA.match(p)
                assert m,('Unrecognized EA',p)
                field,areg=m.groups()
                field=equ.get(field, int(field) if field.lstrip('-').isdigit() else None)
                if field is None:raise AssertionError('Unknown field '+p)
                return e.M(int(areg),field)
            left=operand(left);right=operand(right)
            c.move(left,right,'w' if op.endswith('.w') else 'l');continue
        raise AssertionError('Unsupported R19 instruction '+line)
    if not begun:raise AssertionError('Missing R19 function '+start)
    if axis=='x' and not getp:raise AssertionError('Missing AP20 GetP delimiter')
    return c.out()


class Tests(unittest.TestCase):
    def setUp(self):
        self.src=(ROOT/'src'/'AGA_MOUSE_R19_NATIVE.s').read_text(encoding='ascii')
        data=R19.read_bytes() if R19.exists() else None
        self.lib=data if data is not None and x.sha(data)==x.R19_SHA else None

    def test_source_is_actual_mnemonics(self):
        self.assertIn('movem.l',self.src)
        self.assertIn('movea.l',self.src)
        self.assertIn('beq.w',self.src)
        self.assertNotIn('dc.w $48E7',self.src)

    def test_mouse_machine_code_matches_actual_source(self):
        p=x.parse_lib(self.lib) if self.lib is not None else None
        for name,index in [('x',28),('y',29)]:
            rebuilt=compile_r19_mouse(self.src,name)
            expected=(ROOT/'tests'/'fixtures'/('R19_MOUSE_'+name.upper()+'.bin')).read_bytes()
            self.assertEqual(len(rebuilt),108)
            self.assertEqual(rebuilt,expected)
            if p is not None:self.assertEqual(rebuilt,p['section'][index]['core'])

    def test_complete_r19_restoration_strict(self):
        if self.lib is None:self.skipTest('R19 .Lib fixture not mounted')
        p=x.parse_lib(self.lib)
        asm,meta=x.output(p)
        self.assertEqual(meta['entries'],30)
        self.assertGreater(meta['recognized_percent'],98)
        self.assertFalse(x.unclassified_gaps(p))
        self.assertIn('Aga_Mouse_X:',asm)
        self.assertIn('Aga_Mouse_Y:',asm)
        self.assertIn('movem.l',asm)
        self.assertIn('C_Tk:',asm)
        self.assertIn('C_Lib:',asm)
        self.assertIn('C_Title:',asm)
        self.assertIn('dc.b "GetP"',asm)
        self.assertNotIn('\x00',asm)

    def test_cli_writes_only_export_directory(self):
        if self.lib is None:self.skipTest('R19 .Lib fixture not mounted')
        with tempfile.TemporaryDirectory() as temp:
            output=Path(temp)
            self.assertEqual(x.main(['--lib',str(R19),'--out',str(output),'--strict',
                                     '--baseline','none']),0)
            r=next(output.glob('*.json'))
            m=json.loads(r.read_text())
            self.assertEqual(m['sha256'],x.R19_SHA)
            self.assertEqual(m['unclassified_regions'],[])
            self.assertFalse(m['native_reassembly_verified'])
            self.assertEqual(R19.read_bytes(),self.lib)

    def test_dont_accept_tampered_hunk(self):
        if self.lib is None:self.skipTest('R19 .Lib fixture not mounted')
        broken=bytearray(self.lib);broken[-1]=0
        with self.assertRaises(x.ExportError):x.parse_lib(bytes(broken))

    def test_future_release_adds_entry_automatically(self):
        if self.lib is None:self.skipTest('R19 .Lib fixture not mounted')
        p=x.parse_lib(self.lib)
        # M8 R20 toy fixture: AP20 entry 30 = RTS, no source hardcoding.
        token_name=b'aga smoke'
        def token(name,cmd,fn,sig):
            b=name.encode('ascii');o=__import__('struct').pack('>HH',cmd,fn)
            o+=b[:-1]+bytes([b[-1]|128])+sig.encode('ascii')+b'\xff'
            return o+b'\0'*(len(o)%2)
        tk=p['token_data'][:-6]+token(token_name.decode(),1,len(p['section']),'0')+b'\0'*6
        parts=[a['data'] for a in p['section']]+[b'\x4e\x75']
        title=b'AMOSPro AGA M8 R20 0.8.4 source test\0'
        if len(title)&1:title+=b'\0'
        from struct import pack
        payload=pack('>4I',2*len(parts),len(tk),sum(map(len,parts)),len(title))
        payload+=b'\0\0AP20'+b''.join(pack('>H',len(b)//2) for b in parts)+tk+b''.join(parts)+title+b'\0\0'
        payload+=bytes(-len(payload)%4)
        words=len(payload)//4
        raw=pack('>8I',0x3f3,0,1,0,0,words,0x3e9,words)+payload+pack('>I',0x3f2)
        newer=x.parse_lib(raw)
        asm,meta=x.output(newer)
        self.assertEqual(meta['entries'],31)
        self.assertIn('Entry_30:',asm)
        self.assertIn('aga smoke',asm)
        self.assertFalse(x.unclassified_gaps(newer))

if __name__=='__main__':unittest.main()
